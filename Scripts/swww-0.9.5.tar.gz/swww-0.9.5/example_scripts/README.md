In here you will find example scripts to help you get started writing your own
scripts to work with `swww` for various effects. Currently, there are scripts
for:

  * Randomly going through the images in a directory (swww_randomize.sh)
  * Changing with which image `swww` is initialized according to the time of day
  (swww_init_according_to_time_of_day.sh)
  * Scheduling changes to the wallpaper at different times of day
  (swww_scheduler.sh)
